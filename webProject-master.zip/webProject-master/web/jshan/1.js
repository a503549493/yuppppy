

    function jump(){

        window.location.href="yiye.html";

    }

