package com.config;

public class C3P0Utils {

}
